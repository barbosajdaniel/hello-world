print('-'*20)
print('Nome da Cidade')
print('-'*20)
cidade = str(input('Digite o nome da cidade: ')).strip()
print(cidade[:5].upper() == 'SANTO')

