print('='*11)
print('Média aluno')
print('='*11)
nome = str(input('Nome do aluno: '))
n1 = float(input('Digite uma nota: '))
n2 = float(input('Digite outra nota: '))
m = (n1 + n2)/2
print('A média do aluno {} é {:.1f}'.format(nome, m))