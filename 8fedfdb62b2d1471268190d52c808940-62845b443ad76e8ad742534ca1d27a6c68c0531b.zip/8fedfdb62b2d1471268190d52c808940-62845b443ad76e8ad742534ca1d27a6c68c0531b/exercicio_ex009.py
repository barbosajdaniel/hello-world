print('='*10)
print('Tabuada')
print('='*10)
n1 = int(input('Digite um numero: '))
t1 = n1 * 1
t2 = n1 * 2
t3 = n1 * 3
t4 = n1 * 4
t5 = n1 * 5
t6 = n1 * 6
t7 = n1 * 7
t8 = n1 * 8
t9 = n1 * 9
t10 = n1 * 10
print('-'*15)
print('({}) x ({:2})  = {}'.format(n1, 1, t1))
print('({}) x ({:2})  = {}'.format(n1, 2, t2))
print('({}) x ({:2})  = {}'.format(n1, 3, t3))
print('({}) x ({:2})  = {}'.format(n1, 4, t4))
print('({}) x ({:2})  = {}'.format(n1, 5, t5))
print('({}) x ({:2})  = {}'.format(n1, 6, t6))
print('({}) x ({:2})  = {}'.format(n1, 7, t7))
print('({}) x ({:2})  = {}'.format(n1, 8, t8))
print('({}) x ({:2})  = {}'.format(n1, 9, t9))
print('({}) x ({:2})  = {}'.format(n1, 10, t10))
print('-'*15)