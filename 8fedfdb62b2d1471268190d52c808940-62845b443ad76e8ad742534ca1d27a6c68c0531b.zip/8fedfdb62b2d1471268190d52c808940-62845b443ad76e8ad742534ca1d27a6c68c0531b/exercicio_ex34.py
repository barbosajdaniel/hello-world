print('-'*10)
print('Promoção')
print('-'*10)
n = float(input('Qual o seu salário:R$ '))
if n <= 1250.00:
    aumento = (n * 0.15) + n
    print('Parabéns você teve um aumento de 15% e seu novo salário é R${:.2f}'.format(aumento))
else:
    aumento2 = (n * 0.10) + n
    print('Parabéns você teve um aumento de 10% e seu novo salário é R${:.2f}'.format(aumento2))