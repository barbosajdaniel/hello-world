print('-'*20)
print('Contador de casas decimais')
print('-'*20)
numero = int(input('Digite um numero:'))
unidade = numero // 1 % 10
dezena = numero // 10 % 10
centena = numero // 100 % 10
milhar = numero // 1000 % 10
print('Analisando o numero {}'.format(numero))
print('A unidade é {}'.format(unidade))
print('A dezena é {}'.format(dezena))
print('A centena é {}'.format(centena))
print('O milhar é {}'.format(milhar))