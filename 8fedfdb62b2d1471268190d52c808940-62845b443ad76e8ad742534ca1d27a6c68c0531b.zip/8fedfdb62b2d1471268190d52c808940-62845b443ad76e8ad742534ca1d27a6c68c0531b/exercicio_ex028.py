from random import randint #o computador auto escolhe um numero inteiro
from time import sleep #simula como se o computador estivesse processando
print('-'*25)
print('Qual numero foi escolhido')
print('-'*25)
computador = randint(0, 5) # faz o computador pesar em um numero inteiro com range definido
nescolhido = int(input('Advinhe qual o numero inteiro entre 0 e 5 eu escolhi? ')) #numero escolhido pelo pessoa
print('Processando.......')
sleep(4)
if computador == nescolhido:
    print('Parabéns!!! Eu escolhi o numero {} e você escolheu o numero {}'.format(computador, nescolhido))
else:
    print('Infelizmente o numero que eu escolhi foi {} e você escolheu o numero {}'.format(computador, nescolhido))

