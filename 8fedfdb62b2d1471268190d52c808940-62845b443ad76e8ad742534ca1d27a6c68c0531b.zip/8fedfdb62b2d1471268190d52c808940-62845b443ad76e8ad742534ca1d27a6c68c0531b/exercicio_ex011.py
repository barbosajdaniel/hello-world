print('='*20)
print('Contador de litros')
print('='*20)
altura = float(input('Qual a altura da parede? '))
comprimento = float(input('Qual o comprimento da parede? '))
area = (altura * comprimento)/2
print('Você precisara de {:.2f} litros de tinta'.format(area))