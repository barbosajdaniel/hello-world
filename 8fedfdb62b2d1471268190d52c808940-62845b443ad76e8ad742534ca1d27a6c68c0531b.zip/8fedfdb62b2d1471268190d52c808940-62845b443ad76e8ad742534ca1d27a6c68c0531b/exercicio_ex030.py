print('-'*15)
print('É par ou impar')
print('-'*15)
n = int(input('Digite um numero: ')) #numero digitado pelo usuário
par = n % 2 #calcula o resto da divisáo para provar que é par
if par == 0: #faz a condição de par ser verdadeira
    print('O numero {} é Par'.format(n))
else:
    print('O numero {} é Impar'.format(n))
