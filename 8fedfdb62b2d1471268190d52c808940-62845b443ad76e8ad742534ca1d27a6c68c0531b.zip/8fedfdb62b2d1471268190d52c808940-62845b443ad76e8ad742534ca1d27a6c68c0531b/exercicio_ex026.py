print('-'*20)
print('Encontre a letra A')
print('-'*20)
frase = str(input('Digite seu nome: ')).upper().strip()
print('A letra A aparece {} vezes na frase'.format(frase.count('A')))
print('A primeira letra A apareceu {}'.format(frase.find('A') + 1))
print('A ultima letra A apareceu {}'.format(frase.rfind('A') + 1))

