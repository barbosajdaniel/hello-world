print('-'*30)
print('Conversor celsius de temperatura')
print('-'*30)
celsius = float(input('Qual a tempera? C°'))
kelvin = celsius + 273
Farenheit = 1.8 * celsius + 32
print('Sua temperatud em kelvin é {}k e em Farenheit é {}F'.format(kelvin, Farenheit))