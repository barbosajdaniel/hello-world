from math import sin,cos,tan, radians
print('-'*15)
print('Angulimetro')
print('-'*15)
num = float(input('Digite um angulo: '))
sin1 = sin(radians(num))
cos1 = cos(radians(num))
tan1 = tan(radians(num))
print('O seno = {:.2f} \nO cosseno = {:.2f} \nA tangente = {:.2f} '.format(sin1, cos1, tan1))