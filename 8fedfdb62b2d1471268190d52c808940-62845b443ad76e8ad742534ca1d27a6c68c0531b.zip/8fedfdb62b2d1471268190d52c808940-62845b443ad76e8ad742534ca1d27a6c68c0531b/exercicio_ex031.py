print('-'*18)
print('Preço da passagem')
print('-'*18)
km = float(input('Quantos kms o senhor viajará? ')) #distância da viagem digitada pelo usuário
if km <= 200: #condição para o valor 1
    valor = km * 0.50 #calculo do valor 1
else:
    valor = km * 0.45 #calculo do valor 2
print('O valor da passagem será de R$ {:.2f} reais'.format(valor))
