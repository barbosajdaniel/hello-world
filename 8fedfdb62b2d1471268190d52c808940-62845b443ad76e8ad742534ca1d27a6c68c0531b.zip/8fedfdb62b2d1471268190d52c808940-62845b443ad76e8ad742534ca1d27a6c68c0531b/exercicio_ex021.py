import playsound
playsound.playsound('ex021.mp3')

# ou
#mport pygame

# Inicializando o mixer PyGame
#pygame.mixer.init()

# Iniciando o Pygame
#pygame.init()

#pygame.mixer.music.load('ex021.mp3')
#pygame.mixer.music.play()
#pygame.event.wait()

#or
#import pygame
#pygame.mixer.init()
#pygame.mixer.music.load('ex021.mp3')
#pygame.mixer.music.play()
#input()
#pygame.event.wait()