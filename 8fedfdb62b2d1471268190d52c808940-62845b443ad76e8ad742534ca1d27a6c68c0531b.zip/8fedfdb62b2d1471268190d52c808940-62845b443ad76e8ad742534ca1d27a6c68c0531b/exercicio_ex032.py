print('-'*15)
print('Ano Bissexto')
print('-'*15)
ano = int(input('Digite um ano: ')) #ano escolhido pelo usuário
if ano % 4 == 0 and ano % 100!= 0 or ano % 400 == 0: #condição para o ano ser bisexto onde != é diferente de
    print('O ano de {} é bissexto'.format(ano))
else:
    print('O ano de {} não é bissexto'.format(ano))