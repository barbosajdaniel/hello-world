#outra forma de fazer o ex 31

distancia = float(input('Qual é a distância da sua viagem? '))
print('Você está prestes a começar uma viagem de {}Km'.format(distancia))
preco = distancia * 0.50 if distancia <= 200 else distancia * 0.45 #utilizando a forma simplificada porém mais difícil de visualizar
print('O preço da sua viagem será de R${:.2f}'.format(preco))