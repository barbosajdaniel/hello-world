print('-'*30)
print('Qual o Maior e qual o menor')
print('-'*30)
n1 = float(input('Digite um numero:'))
n2 = float(input('Digite outro numero: '))
n3 = float(input('Digite mais um numero: '))
if n1 > n2:
    print('O número {} é maior que o número {}'.format(n1, n2))
else:
    print('O numero {} não é maior que o numero {}'.format(n1, n2))
if n2 > n3:
    print('O numero {} é maior que o numero {}'.format(n2, n3))
else:
    print('O numero {} não é maior que o numero {}'.format(n2, n3))
if n3 > n1:
    print('O numero {} é maior que o numero {}'.format(n3, n1))
else:
    print('O numero {} não é maior que o numero {}'.format(n3, n1))
if n3 > n2:
    print('O numero {} é maior que o numero {}'.format(n3, n2))
else:
    print('O numero {} não é maior que o numero {}'.format(n3, n2))

