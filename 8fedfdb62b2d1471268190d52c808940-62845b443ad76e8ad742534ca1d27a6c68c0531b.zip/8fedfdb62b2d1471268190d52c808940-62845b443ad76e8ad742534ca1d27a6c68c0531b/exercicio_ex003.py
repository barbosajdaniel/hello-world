print('-------------------------')
print('Média automática de notas')
print('-------------------------')

nome = str(input('Qual o nome do aluno:'))
n1 = int(input('Digite uma nota:'))
n2 = int(input('Digite outro nota:'))
s = (n1 + n2)/2
print('A média do aluno {} foi igual {}  '.format(nome, s))