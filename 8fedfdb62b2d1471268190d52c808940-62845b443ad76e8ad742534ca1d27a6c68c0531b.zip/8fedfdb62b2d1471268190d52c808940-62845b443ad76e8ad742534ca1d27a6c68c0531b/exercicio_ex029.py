print('-'*5)
print('Radar')
print('-'*5)
velocidade = float(input('Qual sua velocidade: ')) #usuario digite um valocidade
if velocidade > 80:
    multa = (velocidade - 80) * 7 #a multa é calculado subtraindo-se o permitido e multiplicando pelo fator de cobrança
    print('A sua velocidade é {:.2f} km/h e por ter ultrapassado a velocidade regulamentada de 70 Km/h você pagara R$ {:.02f} reais de multa'.format(velocidade, multa))
else:
    print('Parabéns você é um motorista muito consciente')
