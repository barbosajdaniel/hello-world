#outra forma de fazer o ex 32
from datetime import date #importa do modulo datetime o library date
ano = int(input('Que ano você quer analisar? Coloque 0 para analisar o ano atual:')) #pede pro usuário digitar zero para o ano atual
if ano == 0: #atribui o ano atual a zero
    ano = date.today().year #condição para ser utilizado o ano atual em que a aplicação está sedo executada
if ano % 4 == 0 and ano % 100 != 0 or ano % 400 == 0:
    print('O ano de {} é bisexto'.format(ano))
else:
    print('O ano de {} não é bisexto'.format(ano))

