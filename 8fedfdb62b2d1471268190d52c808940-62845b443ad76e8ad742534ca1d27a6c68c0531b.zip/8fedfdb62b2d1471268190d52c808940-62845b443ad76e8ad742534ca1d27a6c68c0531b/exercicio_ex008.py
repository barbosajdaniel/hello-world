print('='*22)
print('Conversor de unidades')
print('='*22)
n1 = float(input('Digite um valor: '))
km = n1 / 1000
hm = n1 / 100
dam = n1 / 10
dm = n1 * 10
cent = n1 * 100
mil = n1 * 1000
print('O valor de {}m em km é {} \nO valor de{}m em hectometros é {} \nO valor de {}m em decametros é {} \nO valor de {}m em decimetros é{} \nO valor de {}m em centimetros é{} \nO valor de {}m em milimetros é{}'.format(n1, km, n1, hm, n1, dam, n1, dm, n1, cent, n1, mil))
