'''from math import pow,sqrt
print('-'*26)
print('Descobridor de hipotenusa')
print('-'*26)
catop = float(input('Digite o cateto oposto: '))
catadj = float(input('Digite o cateto adjacente: '))
hipot = sqrt(pow(catop, 2)+(pow(catadj, 2)))
print('A hipotenusa é {:.3f}'.format(hipot))'''

#or

from math import hypot
catop = float(input('Digite o valor do cateto oposto: '))
catadj = float(input('Digite o valor do cateto adjacente: '))
hip = hypot(catop, catadj)
print('O valor da hipotenusa é {:.2f}'.format(hip))