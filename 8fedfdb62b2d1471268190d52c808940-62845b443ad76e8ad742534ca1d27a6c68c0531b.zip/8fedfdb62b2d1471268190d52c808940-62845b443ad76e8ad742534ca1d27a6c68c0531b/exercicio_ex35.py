print('-'*30)
print('Construtor de triangulo')
print('-'*30)
reta1 = int(input('Digite o tamanho da primeira reta:'))
reta2 = int(input('Digite o tamanho da segunda reta: '))
reta3 = int(input('Digite o tamanho da ultima reta: '))
if reta1 - reta2 < reta3 < reta1 + reta2:
    print('É possível construir um triangulo com as retas escolhidas')
else:
    print('Não é possível construir um triagulo com as retas escolhidos')