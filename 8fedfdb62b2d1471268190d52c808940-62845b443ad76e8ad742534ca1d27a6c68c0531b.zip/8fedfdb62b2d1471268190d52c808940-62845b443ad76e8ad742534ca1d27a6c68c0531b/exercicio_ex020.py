from random import shuffle
print('-'*10)
print('Apresentações')
print('-'*10)
n1 = str(input('Primeiro aluno: '))
n2 = str(input('Segundo aluno: '))
n3 = str(input('Terceiro aluno: '))
n4 = str(input('Quarto aluno: '))
lista = [n1, n2, n3, n4]
shuffle(lista)
print('O ordem de apresentação será')
print(lista)
