print('='*20)
print('Conversor de moedas')
print('='*20)
nome = str(input('Qual seu nome: '))
n1 = float(input('Quantos reais você tem {}? R$'.format(nome)))
dolar = n1 / 4.0650
euro = n1 / 4.4898
print('Com R${} \nvocê pode comprar \nU$${:.4f} E EUR{:.4f} '.format(n1, dolar, euro))