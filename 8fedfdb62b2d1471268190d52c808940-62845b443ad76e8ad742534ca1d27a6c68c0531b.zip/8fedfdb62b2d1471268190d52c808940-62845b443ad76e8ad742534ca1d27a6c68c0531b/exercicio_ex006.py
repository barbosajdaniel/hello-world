print('='*18)
print('Leitora de numeros')
print('='*18)
n1 = int(input('Digite um número: '))
d = n1 * 2
d3 = n1 * 3
quad = pow(n1, (1/2)) # ou pode ser feito quad = n1 ** (1/2)
print('O dobro de {} é {}. \nO triplo de {} é {}. \nE a raiz quadrada de {} é {:.2f}.'.format(n1, d, n1, d3, n1, quad))