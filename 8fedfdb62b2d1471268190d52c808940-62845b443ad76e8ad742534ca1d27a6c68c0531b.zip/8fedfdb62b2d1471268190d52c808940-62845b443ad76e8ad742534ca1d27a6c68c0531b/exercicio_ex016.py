'''from math import floor
print('-'*15)
print('Arredondador')
print('-'*15)
num = float(input('Digite um valor: '))
print('O valor arredondado é {}'.format(floor(num)))'''

#or

'''from math import trunc
print('-'*15)
print('Arredondador')
print('-'*15)
num = float(input('Digite um valor: '))
print('O valor arredondado é {}'.format(math.trunc(num)))'''

#or

num = float(input('Digite um numero: '))
print('A parte inteira do valor {} é {}'.format(num, int(num)))


