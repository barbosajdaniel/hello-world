nome = input('Qual seu nome? ')
print('È um prazer te conhecer, {}!'.format(nome))