print('='*32)
print('Antecessor e sucessor de numeros')
print('='*32)
n1 = int(input('digite um numero: '))
a = n1 - 1
b = n1 + 1
print('O antecessor é {} e o sucessor é {}'.format(a, b))